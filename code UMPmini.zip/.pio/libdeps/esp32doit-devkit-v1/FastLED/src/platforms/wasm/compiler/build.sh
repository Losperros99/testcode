#!/bin/bash

python compile.py --no-platformio
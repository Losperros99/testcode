#pragma once

#warning "This header is deprecated. Please use math_macros.h, this header will go away in the version 4.0."

#include "fl/math_macros.h"
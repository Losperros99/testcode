#ifndef MEMORY_H
#define MEMORY_H

#include <Arduino.h>
#include <Preferences.h>

class Memory {
private:
  Preferences *preferences;

public:
  void begin(Preferences *prevs) {
    preferences = prevs;
    // Wenn der Initialisierungswert noch nicht gesetzt wurde, initialisiere den Speicher.
    if (preferences->getInt("memInit", 0) != 2) {
      memInit();
    }
  }

  void memInit() {
    preferences->putInt("memInit", 2);
    setMotorStepsPerRound(1000);
    setMotorPositionInSteps(0);
    setMotorPositionDiffInSteps(0);
    setMotorSpeedInSteps(5000);
    setMotorAccDecInSteps(10000);
    setIncDecValueInSteps(0);
  }

  // *************** MOTOR *****************
  void setMotorStepsPerRound(long value) {
    value = constrain(value, 200, 40000);
    preferences->putLong("mspr", value);
  }
  long getMotorStepsPerRound() {
    return preferences->getLong("mspr", 1000);
  }

  void setMotorDir(bool value) {
    preferences->putBool("md", value);
  }
  bool getMotorDir() {
    return preferences->getBool("md", 0);
  }

  void setMotorMillimeterPerRound(float value) {
    value = constrain(value, 0, 9999);
    preferences->putFloat("mmpr", value);
  }
  float getMotorMillimeterPerRound() {
    return preferences->getFloat("mmpr", 5);
  }

  void setMotorPositionInSteps(long value) {
    preferences->putLong("mpis", value);
  }
  long getMotorPositionInSteps() {
    return preferences->getLong("mpis", 0);
  }

  void setMotorPositionDiffInSteps(long value) {
    preferences->putLong("mpdis", value);
  }
  long getMotorPositionDiffInSteps() {
    return preferences->getLong("mpdis", 0);
  }

  void setMotorSpeedInSteps(long value) {
    preferences->putLong("msis", value);
  }
  long getMotorSpeedInSteps() {
    return preferences->getLong("msis", 5000);
  }

  void setMotorAccDecInSteps(long value) {
    value = constrain(value, 2000, 200000);
    preferences->putLong("mais", value);
  }
  long getMotorAccDecInSteps() {
    return preferences->getLong("mais", 10000);
  }

  void setIncDecSpeed(long value) {
    value = constrain(value, 1, 9999);
    preferences->putLong("ids", value);
  }
  long getIncDecSpeed() {
    return preferences->getLong("ids", 100);
  }

  void setIncDecValueInSteps(long value) {
    preferences->putLong("idvis", value);
  }
  long getIncDecValueInSteps() {
    return preferences->getLong("idvis", 0);
  }

  void setMotorSmoothDec(bool value) {
    preferences->putBool("msd", value);
  }
  bool getMotorSmoothDec() {
    return preferences->getBool("msd", false);
  }

  int getSearchRefOnStart() {
    return preferences->getInt("sros", 0);
  }
  void setSearchRefOnStart(int value) {
    value = constrain(value, 0, 2);
    preferences->putInt("sros", value);
  }

  float getRefValueMm() {
    return preferences->getFloat("rvm", 0);
  }
  void setRefValueMm(float value) {
    value = constrain(value, -9999, 9999);
    preferences->putFloat("rvm", value);
  }

  long getRefSpeed() {
    return preferences->getLong("rs", 1000);
  }
  void setRefSpeed(long value) {
    value = constrain(value, 0, 50000);
    preferences->putLong("rs", value);
  }

  bool getUseSpeedPoti() {
    return preferences->getBool("usp", 0);
  }
  void setUseSpeedPoti(bool value) {
    preferences->putBool("usp", value);
  }

  bool getLcdLightAutoOff() {
    return preferences->getBool("llao", 0);
  }
  void setLcdLightAutoOff(bool value) {
    preferences->putBool("llao", value);
  }

  void setEndStopDec(long value) {
    value = constrain(value, 1000, 200000);
    preferences->putLong("esd", value);
  }
  long getEndStopDec() {
    return preferences->getLong("esd", 200000);
  }

  void setEndStopReturnSpeed(long value) {
    value = constrain(value, 100, 10000);
    preferences->putLong("esrs", value);
  }
  long getEndStopReturnSpeed() {
    return preferences->getLong("esrs", 500);
  }

  void setEndStopAddSteps(long value) {
    value = constrain(value, 0, 50000);
    preferences->putLong("esas", value);
  }
  long getEndStopAddSteps() {
    return preferences->getLong("esas", 10);
  }

  bool getIsDecPos() {
    return preferences->getBool("idp", 1);
  }
  void setIsDecPos(bool value) {
    preferences->putBool("idp", value);
  }

  float getModeInc() {
    return preferences->getFloat("moi", 0);
  }
  void setModeInc(float value) {
    value = constrain(value, -9999, 9999);
    preferences->putFloat("moi", value);
  }

  float getModeDec() {
    return preferences->getFloat("mod", 0);
  }
  void setModeDec(float value) {
    value = constrain(value, -9999, 9999);
    preferences->putFloat("mod", value);
  }

  bool getModeOnOff() {
    return preferences->getBool("moo", 0);
  }
  void setModeOnOff(bool value) {
    preferences->putBool("moo", value);
  }

  float getMinMm() {
    return preferences->getFloat("minmm", 0);
  }
  void setMinMm(float value) {
    preferences->putFloat("minmm", value);
  }

  float getMaxMm() {
    return preferences->getFloat("maxmm", 2000);
  }
  void setMaxMm(float value) {
    preferences->putFloat("maxmm", value);
  }
};

#endif // MEMORY_H

#ifndef DATABANK_H
#define DATABANK_H

#include <Arduino.h>
#include <SD.h>
#include <SPI.h>

/**
 * @brief Klasse zur Verwaltung von Projektdaten, die auf einer SD-Karte gespeichert sind.
 *
 * Die Klasse liest eine Textdatei ein, in der jede Zeile einen Datensatz (z.B. Messwert,
 * Länge, Werkstoff etc.) enthält. Über die Methoden können später die einzelnen Zeilen abgefragt werden.
 */
class Databank {
private:
  String _filename;      // Dateiname (Pfad) der Datei auf der SD-Karte
  int _csPin;            // Chip Select Pin für die SD-Karte
  String* _lines;        // Dynamisch allokiertes Array für die eingelesenen Zeilen
  int _lineCount;        // Anzahl der Zeilen (Datensätze)
  bool _initialized;     // Flag, ob die SD-Karte initialisiert wurde

public:
  /**
   * @brief Konstruktor der Databank-Klasse.
   * @param filename Der Name (inklusive Pfad, z.B. "/projects.txt") der Datei, die eingelesen werden soll.
   */
  Databank(const String &filename)
    : _filename(filename), _csPin(-1), _lines(NULL), _lineCount(0), _initialized(false)
  { }

  /**
   * @brief Destruktor – gibt den allokierten Speicher wieder frei.
   */
  ~Databank() {
    if (_lines != NULL) {
      delete [] _lines;
    }
  }

  /**
   * @brief Initialisiert die SD-Karte.
   * @param csPin Der Chip-Select-Pin, an dem die SD-Karte angeschlossen ist.
   * @return true, wenn die Initialisierung erfolgreich war; andernfalls false.
   */
  bool begin(int csPin) {
    _csPin = csPin;
    if (!SD.begin(_csPin)) {
      Serial.println("SD begin failed");
      _initialized = false;
      return false;
    }
    _initialized = true;
    return true;
  }

  /**
   * @brief Liest die Datei von der SD-Karte und speichert alle Zeilen.
   *
   * Es wird davon ausgegangen, dass die Datei im Klartext vorliegt und jede Zeile einen Datensatz enthält.
   */
  void readProjectsFromSD() {
    if (!_initialized) {
      Serial.println("SD not initialized");
      return;
    }
    File file = SD.open(_filename, FILE_READ);
    if (!file) {
      Serial.println("Error opening file: " + _filename);
      return;
    }
    // Zähle zunächst die Anzahl der Zeilen
    _lineCount = 0;
    while (file.available()) {
      String line = file.readStringUntil('\n');
      _lineCount++;
    }
    file.seek(0);  // Zurück zum Dateianfang

    // Speicher für die Zeilen allokieren
    if (_lines != NULL) {
      delete [] _lines;
    }
    _lines = new String[_lineCount];

    int index = 0;
    while (file.available() && index < _lineCount) {
      String line = file.readStringUntil('\n');
      line.trim();  // Entfernt Leerzeichen am Anfang und Ende
      _lines[index++] = line;
    }
    file.close();
    Serial.print("Loaded ");
    Serial.print(_lineCount);
    Serial.println(" lines from SD.");
  }

  /**
   * @brief Gibt die Anzahl der eingelesenen Zeilen zurück.
   * @return Anzahl der Zeilen.
   */
  int getCount() const {
    return _lineCount;
  }

  /**
   * @brief Gibt die Zeile an der angegebenen Indexposition zurück.
   * @param index Der Index (0-basiert).
   * @return Die Zeile als String. Ist der Index ungültig, wird ein leerer String zurückgegeben.
   */
  String getLine(int index) const {
    if (index >= 0 && index < _lineCount) {
      return _lines[index];
    }
    return "";
  }
};

#endif // DATABANK_H

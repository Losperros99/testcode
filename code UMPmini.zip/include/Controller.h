#ifndef CONTROLLER_H
#define CONTROLLER_H

//************************************************************************************
// Einbindungen
//************************************************************************************
#include "esp32-hal-gpio.h"
#include <Arduino.h>
#include <Adafruit_MCP23X17.h>
#include "Screen.h"
#include "Keypad.h"
#include "Stepper.h"
#include "Memory.h"

//************************************************************************************
// Makrodefinitionen (falls noch nicht definiert)
//************************************************************************************
#ifndef POTI_MEASURES
  #define POTI_MEASURES 25
#endif

#ifndef LCD_LIGHT_PIN
  #define LCD_LIGHT_PIN 15
#endif

#ifndef INC_SW
  #define INC_SW 9
#endif

#ifndef DEC_SW
  #define DEC_SW 10
#endif

#ifndef OSZI_SW
  #define OSZI_SW 11
#endif

#ifndef ID_SW
  #define ID_SW 12
#endif

#ifndef ENA_PIN
  #define ENA_PIN 8
#endif

#ifndef KEYPAD_TRIGGER_MS
  #define KEYPAD_TRIGGER_MS 25
#endif

#ifndef SECONDS_LCD_LIGHT_OFF
  #define SECONDS_LCD_LIGHT_OFF 10
#endif

//************************************************************************************
// Klasse: Controller
//************************************************************************************
class Controller {
private:
  //**********************************************************************************
  // Zeiger auf die verwendeten Submodule
  //**********************************************************************************
  Screen *display;
  Keypad *keypad;
  Stepper *stepper;
  Memory *memory;
  Adafruit_MCP23X17 *mcp;

  //**********************************************************************************
  // Diverse Steuerungs-Flags und Zähler
  //**********************************************************************************
  bool incHold;
  bool decHold;
  bool incSwitch;
  bool decSwitch;
  bool setToZero;
  bool isSetup;
  int setupPage;
  int setupLastPage;
  unsigned long millisOld;
  unsigned long messMillisOld;
  int measCount = 0;
  float measSum = 0;
  float measAvr = 0;
  float oldMeasAvr = 0;
  float avrRunner = 0;
  float oldValue = 0;
  int measWeight = 0;
  float potiValueAvr = 0;
  float measures[POTI_MEASURES];
  float oldSpeedPercent = 0;
  long lightTimer = 0;
  bool inputAction = false;
  bool mRefSwTriggered;
  bool mRefSwActiveAtStrartup;
  int searchRefOnStart;
  bool searchRefStarted;
  bool searchRefOnStartCompleted;
  bool buttonsOff;
  bool osziSwitch;
  bool osziSwDown;
  bool osziOn;
  bool osziUp;
  bool osziIsUp;
  bool osziOneLastMove;
  long osziIncDecSteps;
  unsigned long osziMillis;
  bool eTrigger;
  bool incDecSwitch;
  bool incDecSwitchDown;
  bool incDecSwitchIsMoving;
  bool incDecSwitchIsDec;
  bool waitForMotorStop;

public:
  //**********************************************************************************
  // Methode: begin
  // Beschreibung:
  //   Initialisiert den Controller, indem die Submodule (Screen, Keypad, Stepper, Memory und MCP)
  //   übergeben und Parameter aus dem Memory gesetzt werden.
  //**********************************************************************************
  void begin(Screen *displayClass, Keypad *keypadClass, Stepper *stepperClass, Memory *memClass, Adafruit_MCP23X17 *mcpClass) {
    display = displayClass;
    keypad = keypadClass;
    stepper = stepperClass;
    memory = memClass;
    mcp = mcpClass;
    
    // Initialisiere Steuerungsvariablen
    incHold = false;
    decHold = false;
    setToZero = false;
    setupPage = 1;
    setupLastPage = -1;
    isSetup = false;

    // Setze Parameter des Motors anhand der gespeicherten Werte
    stepper->setSmoothDec(memory->getMotorSmoothDec());
    // Statt setStepperPos() wird updateStepperPos() verwendet, um die aktuelle Position zu setzen
    stepper->updateStepperPos(memory->getMotorPositionInSteps());
    stepper->setStepperIncDecSteps(memory->getIncDecValueInSteps());
    stepper->setStepperSpeed(memory->getMotorSpeedInSteps());
    stepper->setStepperPosDiff(memory->getMotorPositionDiffInSteps());
    stepper->setStepsPerRound(memory->getMotorStepsPerRound());
    stepper->setStepperAccDec(memory->getMotorAccDecInSteps());
    stepper->setMillimeterPerRound(memory->getMotorMillimeterPerRound());
    stepper->setMinMm(memory->getMinMm());
    stepper->setMaxMm(memory->getMaxMm());

    // Setze weitere Motoreinstellungen
    stepper->setMotorDir(memory->getMotorDir());
    stepper->setEndStopDec(memory->getEndStopDec());
    stepper->setEndStopReturnSpeed(memory->getEndStopReturnSpeed());
    stepper->setEndStopAddSteps(memory->getEndStopAddSteps());

    // Konfiguriere MCP-Pins für die externe Hardware
    mcp->pinMode(LCD_LIGHT_PIN, OUTPUT);  // LCD-Beleuchtung
    mcp->pinMode(INC_SW, INPUT_PULLUP);     // INC-Taster
    mcp->pinMode(DEC_SW, INPUT_PULLUP);     // DEC-Taster
    mcp->pinMode(OSZI_SW, INPUT_PULLUP);    // Oszi-Taster
    mcp->pinMode(ID_SW, INPUT_PULLUP);      // Toggle-Taster (INC<->DEC)
    mcp->pinMode(ENA_PIN, OUTPUT);          // ENA-Pin

    // Schalte LCD-Licht ein, falls nicht automatisch ausgeschaltet werden soll
    if (!memory->getLcdLightAutoOff()) {
      mcp->digitalWrite(LCD_LIGHT_PIN, HIGH);
    }
    searchRefOnStart = memory->getSearchRefOnStart();
  }

  //**********************************************************************************
  // Methode: control
  // Beschreibung:
  //   Führt die Hauptsteuerung aus:
  //   - Abfrage und Steuerung der Referenzsuche
  //   - Abfrage des Keypads und Aktualisierung der Motor- und Anzeigeparameter
  //   - Externe Taster (Poti, Oszi, Toggle) werden ausgelesen und verarbeitet
  //**********************************************************************************
  void control() {
    // --- SearchRefOnStart ---
    if (searchRefOnStart != 0 && !searchRefStarted && !searchRefOnStartCompleted && !stepper->getIsEndSwitch()) {
      if (!searchRefStarted) {
        if (millis() > 2500) {
          Serial.println("Search REF....");
          searchRefStarted = true;
          stepper->resetEndSwitchCompleteAction();
          if (searchRefOnStart == 1) {
            stepper->setTargetSpeed(memory->getRefSpeed());
            // Setze Ziel auf minimalen Wert (32-bit-Signed-Int Minimum)
            stepper->setTargetStep(-2147483648);
          }
          if (searchRefOnStart == 2) {
            stepper->setTargetSpeed(memory->getRefSpeed());
            // Setze Ziel auf maximalen Wert (32-bit-Signed-Int Maximum)
            stepper->setTargetStep(2147483647);
          }
        }
      }
    }
    if (searchRefStarted) {
      if (stepper->getEndSwitchCompleteAction()) {
        Serial.println("Complete");
        searchRefOnStartCompleted = true;
        searchRefStarted = false;
        stepper->resetEndSwitchCompleteAction();

        stepper->setStepperPosDiff(0);
        memory->setMotorPositionDiffInSteps(stepper->getStepperPosDiff());
        // Setzt das Ziel in Millimeter anhand des Referenzwerts (absolute Position)
        stepper->setTargetInMillimeter(memory->getRefValueMm(), true);
        memory->setMotorPositionInSteps(stepper->getTargetStep());

        stepper->setStepperSpeed(memory->getMotorSpeedInSteps());
      }
    }
    
    // --- Keypad Mode-Taster ---
    if (keypad->getModePressed()) {
      keypad->resetModePressed();
    }
    
    // --- POTI-Wert lesen ---
    if (millis() - messMillisOld > 1) {
      potiValueAvr = getPotiValue();
      messMillisOld = millis();
    }
    
    // --- Keypad-Polling (alle KEYPAD_TRIGGER_MS Millisekunden) ---
    if (millisOld + KEYPAD_TRIGGER_MS < millis()) {
      keypad->keyTrigger();
      millisOld = millis();

      // Anwendung des POTI-Werts, falls aktiviert
      if (memory->getUseSpeedPoti()) {
        if (potiValueAvr != oldSpeedPercent) {
          if (!searchRefStarted) {
            stepper->setStepperSpeedInPercent(potiValueAvr);
            memory->setMotorSpeedInSteps(stepper->getSettedStepperSpeed());
          }
          oldSpeedPercent = potiValueAvr;
          inputAction = true;
        }
      }
      
      // --- LCD-Lichtsteuerung ---
      if (memory->getLcdLightAutoOff()) {
        if (millis() - lightTimer > SECONDS_LCD_LIGHT_OFF * 1000) {
          mcp->digitalWrite(LCD_LIGHT_PIN, LOW);
        } else {
          mcp->digitalWrite(LCD_LIGHT_PIN, HIGH);
        }
      }
      
      // --- Externe INC/DEC-Taster ---
      incSwitch = !mcp->digitalRead(INC_SW);
      decSwitch = !mcp->digitalRead(DEC_SW);
      if (!incSwitch && !decSwitch && buttonsOff) {
        buttonsOff = false;
      }
      
      // --- Oszi-Taster ---
      osziSwitch = !mcp->digitalRead(OSZI_SW);
      if (osziSwitch && !osziSwDown && !isSetup) {
        osziOn = !osziOn;
        osziSwDown = true;
      }
      if (!osziSwitch && osziSwDown) {
        osziSwDown = false;
      }
      
      // --- Toggle-Taster (INC<->DEC) ---
      incDecSwitch = !mcp->digitalRead(ID_SW);
      if (!incDecSwitch) {
        incDecSwitchDown = false;
      }
      if (incDecSwitch && !incDecSwitchIsMoving && !incDecSwitchDown) {
        incDecSwitchDown = true;
        incDecSwitchIsMoving = true;
        if (memory->getIsDecPos()) {
          stepper->doSingleInc();
          memory->setMotorPositionInSteps(stepper->getTargetStep());
        } else {
          stepper->doSingleDec();
          memory->setMotorPositionInSteps(stepper->getTargetStep());
        }
      }
      if (incDecSwitch && incDecSwitchIsMoving && !incDecSwitchDown) {
        incDecSwitchDown = true;
        incDecSwitchIsMoving = false;
        if (memory->getIsDecPos()) {
          memory->setIsDecPos(false);
        } else {
          memory->setIsDecPos(true);
        }
        stepper->motorSoftStop();
      }
      if (incDecSwitchIsMoving && stepper->targetReached()) {
        if (memory->getIsDecPos()) {
          memory->setIsDecPos(false);
        } else {
          memory->setIsDecPos(true);
        }
        incDecSwitchIsMoving = false;
      }
    }
    
    // --- Oszi-Modus ---
    if (osziOn && isSetup) {
      osziOn = false;
      osziOneLastMove = true;
    }
    if (osziOn || osziOneLastMove) {
      if (!osziUp && !osziIsUp) {
        if (!stepper->motorIsRunning() && !eTrigger) {
          osziIncDecSteps = stepper->getStepperIncDecSteps();
          stepper->doSingleInc(osziIncDecSteps);
          memory->setMotorPositionInSteps(stepper->getTargetStep());
          osziMillis = millis();
          osziIsUp = true;
          osziOneLastMove = true;
        }
      }
      if (osziUp && osziIsUp) {
        if (!stepper->motorIsRunning() && !eTrigger) {
          stepper->doSingleDec(osziIncDecSteps);
          memory->setMotorPositionInSteps(stepper->getTargetStep());
          osziMillis = millis();
          osziIsUp = false;
          osziOneLastMove = false;
        }
      }
      if (stepper->getWaitForTriggerOff()) {
        if (!eTrigger) {
          osziUp = !osziUp;
          osziOneLastMove = false;
          eTrigger = true;
        }
      } else {
        if ((eTrigger && stepper->getEndSwitchCompleteAction()) || !eTrigger) {
          eTrigger = false;
          stepper->resetEndSwitchCompleteAction();
          if (!stepper->motorIsRunning() && millis() - osziMillis > 100 && !eTrigger) {
            osziUp = !osziUp;
          }
        }
      }
    }
    
    // --- LCD-Licht-Timer zurücksetzen ---
    if (!inputAction) {
      inputAction = keypad->getInputAction();
    }
    if (!stepper->targetReached() && inputAction) {
      inputAction = true;
    }
    if (inputAction) {
      lightTimer = millis();
      inputAction = false;
      keypad->resetInputAction();
    }
  }

  //**********************************************************************************
  // Methode: setStartupRefM
  // Beschreibung: Markiert den Start der Referenzsuche
  //**********************************************************************************
  void setStartupRefM() {
    mRefSwActiveAtStrartup = true;
  }

  //**********************************************************************************
  // Methode: refSwitches
  // Beschreibung: Verarbeitet externe Referenzschalter (Endschalter)
  //**********************************************************************************
  void refSwitches(bool swL, bool swM, bool swR) {
    swL = !swL;
    swR = !swR;
    if (swL || swR) {  // Endschalter ausgelöst
      buttonsOff = true;
      stepper->endSwitchTrigger(swL, swR);
    } else {
      stepper->endSwitchTrigger(false, false);
    }
    if (!swM) {
      if (!mRefSwTriggered) {
        mRefSwTriggered = true;
        if (!mRefSwActiveAtStrartup) {
          stepper->doSingleInc();
        } else {
          mRefSwActiveAtStrartup = false;
        }
      }
    } else {
      if (mRefSwTriggered) {
        stepper->doSingleDec();
        mRefSwTriggered = false;
      }
    }
  }

  //**********************************************************************************
  // Methode: getPotiValue
  // Beschreibung: Liest den POTI-Wert von analogen Pins und berechnet einen Durchschnittswert
  //**********************************************************************************
  float getPotiValue() {
    long value = 0;
    float weight = 0.2;
    measSum = 0;
    int oversampling = 20;
    for (int i = 0; i < oversampling; i++) {
      value += analogRead(36);
      value += analogRead(39);
      value += analogRead(34);
      value += analogRead(35);
    }
    value /= (oversampling * 4);
    for (int i = 1; i < POTI_MEASURES; i++) {
      measures[i - 1] = measures[i];
    }
    measures[POTI_MEASURES - 1] = (value * weight) + (measures[POTI_MEASURES - 1] * (1 - weight));
    for (int i = 0; i < POTI_MEASURES; i++) {
      measSum += measures[i];
    }
    measAvr = measSum / POTI_MEASURES;
    measAvr /= 40.95;
    measAvr = round(measAvr * 10) / 10.0;
    if (measAvr > avrRunner) {
      avrRunner += fabs(measAvr - avrRunner) / 10;
    }
    if (measAvr < avrRunner) {
      avrRunner -= fabs(measAvr - avrRunner) / 10;
    }
    if (fabs(measAvr - avrRunner) < 0.1 && measAvr != oldMeasAvr) {
      measAvr = oldMeasAvr;
    }
    oldMeasAvr = measAvr;
    return measAvr;
  }

  //**********************************************************************************
  // Methoden zur Steuerung des Motors
  //**********************************************************************************
  void setPos(float value) {
    // Setzt das Ziel in Millimeter und speichert den Zielwert
    stepper->setTargetInMillimeter(value);
    memory->setMotorPositionInSteps(stepper->getTargetStep());
  }

  void setSpeed(int value) {
    // Setzt die Geschwindigkeit in mm/s und speichert den neuen Wert
    stepper->setSpeedInMillimeterPerSecond(value);
    memory->setMotorSpeedInSteps(stepper->getSettedStepperSpeed());
  }

  void setIncDec(float value) {
    // Setzt den INC/DEC-Wert in mm und speichert den neuen Wert
    stepper->setIncDecInMillimeter(value);
    memory->setIncDecValueInSteps(stepper->getStepperIncDecSteps());
  }

  void doInc() {
    // Führt einen einzelnen INC-Schritt aus und aktualisiert den Speicher
    stepper->doSingleInc();
    memory->setMotorPositionInSteps(stepper->getTargetStep());
  }

  void doDec() {
    // Führt einen einzelnen DEC-Schritt aus und aktualisiert den Speicher
    stepper->doSingleDec();
    memory->setMotorPositionInSteps(stepper->getTargetStep());
  }

  void setRelativePos(float value) {
    // Setzt die relative Positionsdifferenz (in mm) und speichert den neuen Wert
    stepper->setTargetInMillimeter(value);
    memory->setMotorPositionDiffInSteps(stepper->getStepperPosDiff());
  }

  void resetRelativePos() {
    // Setzt die relative Positionsdifferenz auf 0 und speichert diesen Zustand
    stepper->setStepperPosDiff(0);
    memory->setMotorPositionDiffInSteps(stepper->getStepperPosDiff());
  }

  void motorStop() {
    // Stoppt den Motor weich und speichert den aktuellen Zielwert
    stepper->motorSoftStop();
    memory->setMotorPositionInSteps(stepper->getTargetStep());
  }

  //**********************************************************************************
  // SCREEN-Funktionen
  //**********************************************************************************
  void updateDisplay() {
    if (keypad->getInputBegin()) {
      screenInput(keypad->getNumberString());
      if (keypad->getInputEnd()) {
        if (keypad->getInputEnd() == 1) {  // RETURN
          Serial.print("Input Number: ");
          Serial.println(keypad->getInputNumber());
          if (!isSetup) {
            if (memory->getModeOnOff()) {
              // Optionale Modusumschaltung
            }
            stepper->setTargetInMillimeter(float(keypad->getInputNumber()));
            memory->setMotorPositionInSteps(stepper->getTargetStep());
          } else {
            // --- SETUP-Modus ---
            switch (setupPage) {
              case 0:
                stepper->resetPosition();
                ESP.restart();
                break;
              case 1:
                stepper->setStepsPerRound(long(keypad->getInputNumber()));
                memory->setMotorStepsPerRound(long(keypad->getInputNumber()));
                break;
              case 2:
                stepper->setMotorDir(bool(keypad->getInputNumber()));
                memory->setMotorDir(bool(keypad->getInputNumber()));
                break;
              case 3:
                memory->setMotorAccDecInSteps(long(keypad->getInputNumber()));
                stepper->setStepperAccDec(memory->getMotorAccDecInSteps());
                break;
              case 4:
                stepper->setSmoothDec(long(keypad->getInputNumber()));
                memory->setMotorSmoothDec(stepper->getSmoothDec());
                break;
              case 5:
                stepper->setMillimeterPerRound(float(keypad->getInputNumber()));
                memory->setMotorMillimeterPerRound(float(keypad->getInputNumber()));
                break;
              case 6:
                memory->setSearchRefOnStart(keypad->getInputNumber());
                break;
              case 7:
                memory->setRefValueMm(keypad->getInputNumber());
                break;
              case 8:
                memory->setRefSpeed(keypad->getInputNumber());
                break;
              case 9:
                memory->setEndStopDec(keypad->getInputNumber());
                stepper->setEndStopDec(memory->getEndStopDec());
                break;
              case 10:
                memory->setEndStopReturnSpeed(keypad->getInputNumber());
                stepper->setEndStopReturnSpeed(memory->getEndStopReturnSpeed());
                break;
              case 11:
                memory->setEndStopAddSteps(keypad->getInputNumber());
                stepper->setEndStopAddSteps(memory->getEndStopAddSteps());
                break;
              case 12:
                memory->setUseSpeedPoti(keypad->getInputNumber());
                break;
              case 13:
                memory->setLcdLightAutoOff(keypad->getInputNumber());
                break;
              case 14:
                memory->setMinMm(keypad->getInputNumber());
                stepper->setMinMm(keypad->getInputNumber());
                break;
              case 15:
                memory->setMaxMm(keypad->getInputNumber());
                stepper->setMaxMm(keypad->getInputNumber());
                break;
              case 16:
                stepper->updateStepperPos(keypad->getInputNumber());
                memory->setMotorPositionInSteps(stepper->getCurrentPosition());
                break;
              case 17:
                if (keypad->getInputNumber() == 1) {
                  keypad->resetSetup();
                  searchRefStarted = false;
                  searchRefOnStartCompleted = false;
                  searchRefOnStart = memory->getSearchRefOnStart();
                }
                break;
            }
          }
        }
        if (keypad->getInputEnd() == 2) {  // SPEED
          Serial.print("Input Number Speed: ");
          Serial.println(keypad->getInputNumber());
          stepper->setSpeedInMillimeterPerSecond(long(keypad->getInputNumber()));
          memory->setMotorSpeedInSteps(stepper->getSettedStepperSpeed());
        }
        if (keypad->getInputEnd() == 3) {  // INC
          Serial.print("Input Number INC: ");
          Serial.println(keypad->getInputNumber());
          stepper->setIncDecInMillimeter(float(keypad->getInputNumber()));
          memory->setIncDecValueInSteps(stepper->getStepperIncDecSteps());
          keypad->resetIncDecPressed();
        }
        if (keypad->getInputEnd() == 4) {  // DEC
          Serial.print("Input Number DEC: ");
          Serial.println(keypad->getInputNumber());
          stepper->setIncDecInMillimeter(float(keypad->getInputNumber()));
          memory->setIncDecValueInSteps(stepper->getStepperIncDecSteps());
          keypad->resetIncDecPressed();
        }
        keypad->resetInputBegin();
        keypad->resetInputEnd();
        display->clear();
      }
    } else {
      if (keypad->getReturnOnly()) {
        keypad->resetReturnOnly();
      }
      if (keypad->getMotorStop()) {
        stepper->motorSoftStop();
        searchRefOnStart = 0;
        searchRefOnStartCompleted = true;
        searchRefStarted = false;
        waitForMotorStop = true;
        keypad->resetMotorStop();
      }
      if (waitForMotorStop) {
        if (stepper->getStepperSpeed() == 0) {
          memory->setMotorPositionInSteps(stepper->getCurrentPosition());
          waitForMotorStop = false;
        }
      }
      if (keypad->getSetToZero()) {
        if (!isSetup) {
          if (!setToZero) {
            setToZero = true;
            if (stepper->getPositionInMillimeter() != 0) {
              stepper->updateStepperPos(0);
              Serial.println("Pos to 0");
            } else {
              stepper->setStepperPosDiff(0);
              Serial.println("Diff to 0");
            }
            memory->setMotorPositionDiffInSteps(stepper->getStepperPosDiff());
          }
        } else {
          if (setToZero) {
            setToZero = false;
          }
        }
        Serial.println("RESET");
        keypad->resetSetToZero();
        setToZero = false;
      }
      if (keypad->getIncPressed()) {
        if (!isSetup) {
          if (!osziOn && !osziOneLastMove) {
            if (memory->getModeOnOff()) {
              // Optionale Modusumschaltung
            }
            stepper->doSingleInc();
            memory->setMotorPositionInSteps(stepper->getTargetStep());
          }
        } else {
          setupPage--;
          if (setupPage < 1) {
            setupPage = 17;
          }
        }
        keypad->resetIncDecPressed();
      }
      if (keypad->getDecPressed()) {
        if (!isSetup) {
          if (!osziOn && !osziOneLastMove) {
            if (memory->getModeOnOff()) {
              // Optionale Modusumschaltung
            }
            stepper->doSingleDec();
            memory->setMotorPositionInSteps(stepper->getTargetStep());
          }
        } else {
          setupPage++;
          if (setupPage > 17) {
            setupPage = 1;
          }
        }
        keypad->resetIncDecPressed();
      }
      if ((keypad->getIncHold() || (incSwitch && !decSwitch)) && !buttonsOff) {
        if (!incHold) {
          if (!isSetup) {
            if (!stepper->getIsEndSwitch()) {
              stepper->runToInc();
            }
            incHold = true;
          } else {
            keypad->resetIncDecPressed();
          }
        }
      } else {
        if (incHold) {
          if (!stepper->getIsEndSwitch()) {
            stepper->motorSoftStop();
            memory->setMotorPositionInSteps(stepper->getTargetStep());
          }
          keypad->resetIncDecPressed();
          incHold = false;
        }
      }
      if ((keypad->getDecHold() || (!incSwitch && decSwitch)) && !buttonsOff) {
        if (!decHold) {
          if (!isSetup) {
            Serial.println("DECHOLD...");
            if (!stepper->getIsEndSwitch()) {
              stepper->runToDec();
            }
            decHold = true;
          } else {
            keypad->resetIncDecPressed();
          }
        }
      } else {
        if (decHold) {
          if (!stepper->getIsEndSwitch()) {
            stepper->motorSoftStop();
            memory->setMotorPositionInSteps(stepper->getTargetStep());
          }
          keypad->resetIncDecPressed();
          decHold = false;
        }
      }
      if (keypad->getSetup()) {
        isSetup = true;
        screenSetup(setupPage);
      } else {
        if (isSetup) {
          display->clear();
          isSetup = false;
          setupLastPage = -1;
        }
        screenNormalProg0();
      }
    }
    if (keypad->getInputEnd() == -1) {
      keypad->resetInputEnd();
    }
  }

  //**********************************************************************************
  // Anzeige-Funktionen
  //**********************************************************************************
  void screenInput(String value) {
    display->showInput(value);
  }

  void screenNormalProg0() {
    display->showFloat(9, 0, stepper->getPositionInMillimeter(), 9, 2, 1);
    if (stepper->getStepperPosDiff() == 0) {
      display->showCustomChar(15, 0, 6);
    } else {
      display->showCustomChar(15, 0, 7);
    }
    display->showFloat(0, 1, stepper->getIncDecInMillimeter(), 0, 0, 1);
    display->showLong(13, 1, stepper->getSpeedInMillimeterPerSecond(), 5, 2, 3);
    if (memory->getModeOnOff()) {
      display->print(0, 0, " ");
    } else {
      display->print(0, 0, " ");
    }
  }

  void screenSetup(int page) {
    if (page != setupLastPage) {
      display->clear();
      setupLastPage = page;
    }
    switch (page) {
      case 0:
        display->print(0, 0, "1:MM 2:DEG 3:UPM");
        break;
      case 1:
        display->print(0, 0, "MOTOR STEPS/U");
        display->showLong(0, 1, stepper->getStepsPerRound(), 0, 0, 0);
        break;
      case 2:
        display->print(0, 0, "MOTOR DIR");
        display->showLong(0, 1, stepper->getMotorDir(), 0, 0, 0);
        break;
      case 3:
        display->print(0, 0, "ACC+DEC Hz/s2");
        display->showLong(0, 1, stepper->getStepperAccDec(), 0, 0, 0);
        break;
      case 4:
        display->print(0, 0, "SMOOTH DEC");
        display->showLong(0, 1, stepper->getSmoothDec(), 0, 0, 0);
        break;
      case 5:
        display->print(0, 0, "MOTOR MM/U");
        display->showFloat(0, 1, memory->getMotorMillimeterPerRound(), 0, 0, 0);
        break;
      case 6:
        display->print(0, 0, "SEARCH REF ON ST");
        display->showLong(0, 1, memory->getSearchRefOnStart(), 0, 0, 0);
        break;
      case 7:
        display->print(0, 0, "REF VALUE MM");
        display->showFloat(0, 1, memory->getRefValueMm(), 0, 0, 0);
        break;
      case 8:
        display->print(0, 0, "REF SPD Hz/s");
        display->showLong(0, 1, memory->getRefSpeed(), 0, 0, 0);
        break;
      case 9:
        display->print(0, 0, "STOP DEC Hz/s");
        display->showLong(0, 1, memory->getEndStopDec(), 0, 0, 0);
        break;
      case 10:
        display->print(0, 0, "RET SPD Hz/s");
        display->showLong(0, 1, memory->getEndStopReturnSpeed(), 0, 0, 0);
        break;
      case 11:
        display->print(0, 0, "RET ADD STEPS");
        display->showLong(0, 1, memory->getEndStopAddSteps(), 0, 0, 0);
        break;
      case 12:
        display->print(0, 0, "USE SPEED POTI");
        display->showLong(0, 1, memory->getUseSpeedPoti(), 0, 0, 0);
        break;
      case 13:
        display->print(0, 0, "LIGHT AUTO OFF");
        display->showLong(0, 1, memory->getLcdLightAutoOff(), 0, 0, 0);
        break;
      case 14:
        display->print(0, 0, "MIN MM");
        display->showLong(0, 1, memory->getMinMm(), 0, 0, 0);
        break;
      case 15:
        display->print(0, 0, "MAX MM");
        display->showLong(0, 1, memory->getMaxMm(), 0, 0, 0);
        break;
      case 16:
        display->print(0, 0, "SET ABS POS");
        display->showFloat(0, 1, stepper->getAbsPositionInMillimeter(), 0, 0, 0);
        break;
      case 17:
        display->print(0, 0, "SEARCH REF NOW");
        display->print(0, 1, "1 = OK");
        break;
    }
  }
};

#endif // CONTROLLER_H

#ifndef SCREEN_H
#define SCREEN_H

#include <Arduino.h>
#include <LiquidCrystal.h>
#include <math.h>

class Screen {
private:
  LiquidCrystal *display;
  byte customCharMm[8] = { B11010, B10101, B10101, B00000, B11010, B10101, B10101, B00000 };
  byte customCharMode[8] = { B10001, B11011, B10101, B10001, B00100, B01110, B00100, B00000 };
  byte customCharPs[8] = { B00001, B00010, B00100, B01011, B10100, B00010, B00001, B00110 };
  byte customCharDeg[8] = { B00110, B01001, B01001, B00110, B00000, B00000, B00000, B00000 };
  byte customCharPm[8] = { B00100, B01000, B10000, B00000, B11110, B10101, B10101, B00000 };
  byte customCharU[8] = { B10010, B10010, B10010, B01100, B00001, B00010, B00100, B00000 };
  byte customCharABS[8] = { B01110, B10001, B11111, B10001, B10001, B00000, B00000, B00000 };
  byte customCharREL[8] = { B11110, B10001, B11111, B10010, B10001, B00000, B00000, B00000 };

  String oldInputValue = "X";
public:
  void begin(LiquidCrystal *disp) {
    display = disp;
    display->createChar(0, customCharMm);
    display->createChar(1, customCharMode);
    display->createChar(2, customCharPs);
    display->createChar(3, customCharDeg);
    display->createChar(4, customCharU);
    display->createChar(5, customCharPm);
    display->createChar(6, customCharABS);
    display->createChar(7, customCharREL);
    display->clear();
  }
  void clear() {
    display->clear();
    oldInputValue = "X";
  }

  void showInput(String value) {
    display->setCursor(0, 0);
    display->print("    EINGABE     ");
    if (oldInputValue != value) {
      display->setCursor(0, 1);
      display->print("                ");
      oldInputValue = value;
    }
    display->setCursor(0, 1);
    display->print(value);
  }

  void showCustomChar(int x, int y, int charNo) {
    display->setCursor(x, y);
    display->write(byte(charNo));
  }
  void print(int x, int y, String text) {
    display->setCursor(x, y);
    display->print(text);
  }
  void showLong(int x, int y, long value, int valueSpace = 5, int align = 0, int unit = 0) {
    showNumber(x, y, value, valueSpace, align, true, 0, unit);
  }

  void showFloat(int x, int y, float value, int valueSpace = 5, int align = 0, int unit = 0) {
    showNumber(x, y, value, valueSpace, align, false, 2, unit);
  }

  void showNumber(int x, int y, float value, int valueSpace, int align, bool isInt, int numDec, int unit) {
    String strValue;
    int len = 0, lenDiff = 0, uX = 0;  // Initialisiert auf 0
    if (!isInt) {
      value = value * pow(10, numDec);
      value = round(value);
      value = value / pow(10, numDec);
    } else {
      value = round(value);
    }

    strValue = String(value, numDec);
    len = strValue.length();
    if (valueSpace > len) {
      for (int i = len; i < valueSpace; i++) {
        if (align == 2) {
          strValue = " " + strValue;
        }
        if (align == 0) {
          strValue = strValue + " ";
        }
        lenDiff = i - len;
      }
    }
    if (align == 0) {
      display->setCursor(x, y);
      uX = x + len;
    }
    if (align == 1) {
      display->setCursor(x - 1 - (len / 2) - lenDiff, y);
      uX = x + len - (len / 2);
    }
    if (align == 2) {
      display->setCursor(x - len - lenDiff, y);
      uX = x + 1;
    }
    display->print(strValue);
    if (unit == 1) {
      display->setCursor(uX, y);
      display->write(byte(0));
    }
    if (unit == 2) {
      display->setCursor(uX, y);
      display->write(byte(1));
    }
    if (unit == 3) {
      display->setCursor(uX, y);
      display->write(byte(0));
      display->write(byte(2));
    }
    if (unit == 4) {
      display->setCursor(uX, y);
      display->write(byte(1));
      display->write(byte(2));
    }
    if (unit == 5) {
      display->setCursor(uX, y);
      display->write(byte(3));
    }
    if (unit == 6) {
      display->setCursor(uX, y);
      display->write(byte(3));
      display->write(byte(2));
    }
    if (unit == 7) {
      display->setCursor(uX, y);
      display->write(byte(4));
      display->write(byte(5));
    }
    if (unit == 8) {
      display->setCursor(uX, y);
      display->write(byte(6));
      display->write(byte(5));
    }
  }
};

#endif  // SCREEN_H

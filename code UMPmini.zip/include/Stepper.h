#ifndef STEPPER_H
#define STEPPER_H

#include <Arduino.h>
#include "esp32-hal-gpio.h"
#include "TMC4210.h"      // Stelle sicher, dass du diese Bibliothek hast
#include <Adafruit_MCP23X17.h>

// Dummy-Definitionen für nicht verwendete Pins (falls nicht anderswo definiert)
#ifndef ENA_PIN
  #define ENA_PIN 0
#endif
#ifndef REF_SW_R
  #define REF_SW_R 0
#endif
#ifndef REF_SW_L
  #define REF_SW_L 0
#endif

// Falls TMC4210-bezogene Konstanten nicht definiert sind, setze hier Standardwerte:
#ifndef TMC4210_CLK_FREQ
  #define TMC4210_CLK_FREQ 16000000L
#endif
#ifndef TMC4210_MIN_SPEED
  #define TMC4210_MIN_SPEED 100
#endif
#ifndef TMC4210_MAX_SPEED
  #define TMC4210_MAX_SPEED 50000
#endif
#ifndef TMC4210_MAX_ACC
  #define TMC4210_MAX_ACC 200000
#endif

class Stepper {
private:
  TMC4210 *tmc;
  Adafruit_MCP23X17 *mcp;
  volatile float oscFreq = TMC4210_CLK_FREQ;
  volatile long stepperPos;
  long stepperPosDiff;
  long stepperTarget;
  long stepperTargetTmp;
  long stepperTargetSpeed;
  long incDecSteps;
  long incDecSpeed;
  long stepperAcc;
  long stepperDec;
  long stepperSpeed;
  long stepperSpeedSet;
  volatile float timerSpeed;
  long stepperMinSpeed;
  long stepperMaxSpeed;
  long oldSpeed;
  bool motorOff;
  long endStopDec;
  long endStopReturnSpeed;
  long endStopAddSteps;
  bool endStopTargetSet;
  bool overshot;
  unsigned long overshotTime;
  
  bool isError;
  int errorCode = 0;
  
  volatile long timerMic, timerMicOld;
  
  int dir;
  int requiredDir;
  bool busy;
  bool isDecelerating;
  long stepsToDec;
  
  float mmPerRound;
  long stepsPerRound;
  long stepperMaxAccDec;
  
  bool noMove;
  bool isSoftStop;
  bool isEndSwitch;
  int endSwitchDir;
  bool waitForTriggerOff;
  bool returnSetted;
  bool smoothDec;
  bool endSwitchCompleteAction;
  bool motorDir;
  bool enaOff;
  unsigned long enaTimer;
  bool endSwitchTriggered;
  long minStep;
  long maxStep;
  
public:
  void begin(TMC4210 *tmcClass, Adafruit_MCP23X17 *mcpClass) {
    tmc = tmcClass;
    mcp = mcpClass;
    stepperPos = 0;
    stepperPosDiff = 0;
    stepperTarget = 0;
    incDecSteps = 0;
    stepperMinSpeed = TMC4210_MIN_SPEED;
    stepperMaxSpeed = TMC4210_MAX_SPEED;
    // Beispielwerte für Beschleunigung – passe nach Bedarf an:
    stepperAcc = 40000;
    stepperMaxAccDec = TMC4210_MAX_ACC;
    stepsPerRound = 1000;
    mmPerRound = 5;
    stepperSpeed = stepperMinSpeed;
    dir = 1;
    noMove = false;
    mcp->pinMode(ENA_PIN, OUTPUT);
    setStepperSpeed(10000);
  }
  
  void process() {
    stepperPos = tmc->getCurrentPosition();
    if (isSoftStop) {
      if (tmc->getCurrentSpeed() == 0) {
        tmc->setTargetPosition(tmc->getCurrentPosition());
        tmc->setMaxSpeed(stepperSpeedSet);
        tmc->setAcceleration(stepperAcc);
        isSoftStop = false;
      }
    }
    if (tmc->isTargetReached()) {
      if (millis() - enaTimer > 1000) {
        ena(false);
      }
    } else {
      ena(true);
      enaTimer = millis();
    }
  }
  
  bool getWaitForTriggerOff() {
    return waitForTriggerOff;
  }
  bool getEndSwitchCompleteAction() {
    return endSwitchCompleteAction;
  }
  void resetEndSwitchCompleteAction() {
    endSwitchCompleteAction = false;
  }
  
  void endSwitchTrigger(bool isTriggeredLeft, bool isTriggeredRight) {
    if ((isTriggeredLeft || isTriggeredRight) && !isEndSwitch) {
      motorSoftStop();
      while (!(tmc->getCurrentSpeed() == 0)) {}
      isEndSwitch = true;
      if (isTriggeredLeft) {
        endSwitchDir = 1;
      }
      if (isTriggeredRight) {
        endSwitchDir = -1;
      }
    }
    if (isTriggeredLeft && isTriggeredRight) {
      tmc->stop();
      isError = true;
    }
    if (isEndSwitch) {
      if (digitalRead(REF_SW_R) && endSwitchDir == -1 && !waitForTriggerOff) {
        Serial.println("OVERSHOT R");
        overshot = true;
        overshotTime = millis();
      }
      if (digitalRead(REF_SW_L) && endSwitchDir == 1 && !waitForTriggerOff) {
        Serial.println("OVERSHOT L");
        overshot = true;
        overshotTime = millis();
      }
      if (!waitForTriggerOff) {
        Serial.print("Wait for Trigger OFF.. ");
        Serial.println(endSwitchDir);
        tmc->setAcceleration(endStopDec);
        tmc->setTargetSpeed(endStopReturnSpeed);
        tmc->setTargetPosition(tmc->getCurrentPosition() + (endSwitchDir * 1000000));
        waitForTriggerOff = true;
      } else {
        if (!overshot) {
          if (endSwitchDir == -1 && !isTriggeredRight) {
            tmc->setTargetPosition(tmc->getCurrentPosition() + (endSwitchDir * endStopAddSteps));
            Serial.println("Stop R");
            while (!tmc->isTargetReached()) {}
            isEndSwitch = false;
            waitForTriggerOff = false;
            endSwitchCompleteAction = true;
            tmc->setMaxSpeed(stepperSpeedSet);
            tmc->setAcceleration(stepperAcc);
          }
          if (endSwitchDir == 1 && !isTriggeredLeft) {
            tmc->setTargetPosition(tmc->getCurrentPosition() + (endSwitchDir * endStopAddSteps));
            Serial.println("Stop L");
            while (!tmc->isTargetReached()) {}
            isEndSwitch = false;
            waitForTriggerOff = false;
            endSwitchCompleteAction = true;
            tmc->setMaxSpeed(stepperSpeedSet);
            tmc->setAcceleration(stepperAcc);
          }
        } else {
          tmc->setTargetPosition(tmc->getCurrentPosition() + (endSwitchDir * 1000000));
          endSwitchCompleteAction = false;
          if (millis() > overshotTime + 5000) {
            overshot = false;
            Serial.println("ERROR");
          }
          if (endSwitchDir == -1 && isTriggeredRight) {
            overshot = false;
            Serial.println("Overshot Reset R");
          }
          if (endSwitchDir == 1 && isTriggeredLeft) {
            overshot = false;
            Serial.println("Overshot Reset L");
          }
          if (isTriggeredLeft || isTriggeredRight) {
            overshot = false;
          }
        }
      }
    }
  }
  
  bool getIsEndSwitch() {
    return isEndSwitch;
  }
  
  void motorSoftStop() {
    tmc->setAcceleration(endStopDec);
    tmc->stop();
    while (!(tmc->getCurrentSpeed() == 0)) {}
    isSoftStop = true;
  }
  
  // Grundeinstellungen
  void setStepsPerRound(long value) {
    stepsPerRound = value;
  }
  long getStepsPerRound() {
    return stepsPerRound;
  }
  void setMillimeterPerRound(float value) {
    mmPerRound = value;
  }
  float getMillimeterPerRound() {
    return mmPerRound;
  }
  
  void setMinMm(float value) {
    minStep = round((value / mmPerRound) * float(stepsPerRound));
  }
  void setMaxMm(float value) {
    maxStep = round((value / mmPerRound) * float(stepsPerRound));
  }
  
  // Motorstart/Motorstopp
  void motorStart() {
    motorOff = false;
    setStepperSpeed(stepperTargetSpeed);
    Serial.println(stepperTargetSpeed);
  }
  void motorStop() {
    tmc->setTargetSpeed(0);
    motorOff = true;
  }
  bool motorIsRunning() {
    return (tmc->getCurrentSpeed() != 0);
  }
  
  // Ziel in Millimeter setzen – jetzt mit zwei Parametern:
  float setTargetInMillimeter(float value, bool absolute = false) {
    long stepValue = round((value / mmPerRound) * float(stepsPerRound));
    float mmValue = (float(stepValue) / float(stepsPerRound)) * mmPerRound;
    mmValue = round(mmValue * 100) / 100.0;
    if (!absolute) {
      if (stepValue - stepperPosDiff > maxStep) {
        setTargetStep(maxStep);
      } else if (stepValue - stepperPosDiff < minStep) {
        setTargetStep(minStep);
      } else {
        setTargetStep(stepValue - stepperPosDiff);
      }
    } else {
      updateStepperPos(stepValue);
    }
    return mmValue;
  }
  float getTargetInMillimeter() {
    float mmValue = (float(stepperTarget + stepperPosDiff) / float(stepsPerRound)) * mmPerRound;
    mmValue = round(mmValue * 100) / 100.0;
    return mmValue;
  }
  
  // Aktuelle Position in Millimeter (relativ und absolut)
  float getPositionInMillimeter() {
    float mmValue = (float(stepperPos + stepperPosDiff) / float(stepsPerRound)) * mmPerRound;
    mmValue = round(mmValue * 100) / 100.0;
    return mmValue;
  }
  float getAbsPositionInMillimeter() {
    float mmValue = (float(stepperPos) / float(stepsPerRound)) * mmPerRound;
    mmValue = round(mmValue * 100) / 100.0;
    return mmValue;
  }
  
  long getCurrentPosition() {
    return tmc->getCurrentPosition();
  }
  
  // Geschwindigkeit in mm/s
  void setSpeedInMillimeterPerSecond(long value) {
    long speedTmp = round(float(stepsPerRound) / mmPerRound * value);
    speedTmp = constrain(speedTmp, stepperMinSpeed, stepperMaxSpeed);
    setStepperSpeed(speedTmp);
  }
  long getSpeedInMillimeterPerSecond() {
    long speedTmp = round((mmPerRound * stepperSpeedSet) / float(stepsPerRound));
    return speedTmp;
  }
  
  // Inc/Dec-Wert in mm
  void setIncDecInMillimeter(float value) {
    long stepValue = round((constrain(value, 0, 9999) / mmPerRound) * float(stepsPerRound));
    setStepperIncDecSteps(stepValue);
  }
  float getIncDecInMillimeter() {
    float mmValue = (float(getStepperIncDecSteps()) / float(stepsPerRound)) * mmPerRound;
    mmValue = round(mmValue * 100) / 100.0;
    return mmValue;
  }
  
  // Smooth Deceleration
  bool getSmoothDec() {
    return smoothDec;
  }
  void setSmoothDec(bool value) {
    smoothDec = value;
    if (value) {
      tmc->setRampMode(tmc->SOFT_MODE);
    } else {
      tmc->setRampMode(tmc->RAMP_MODE);
    }
  }
  
  // Endschalter-Parameter
  void setEndStopAddSteps(long value) {
    endStopAddSteps = value;
  }
  void setEndStopDec(long value) {
    endStopDec = value;
  }
  void setEndStopReturnSpeed(long value) {
    endStopReturnSpeed = value;
  }
  
  // Motorrichtung
  void setMotorDir(bool value) {
    motorDir = value;
    tmc->setOutputsPolarity(true, motorDir);
  }
  void ena(bool value) {
    mcp->digitalWrite(ENA_PIN, !value);
  }
  bool getMotorDir() {
    return motorDir;
  }
  
  void resetPosition() {
    setStepperSpeed(0);
    tmc->setCurrentPosition(0);
    setTargetStep(0);
  }
  
  void runToInc() {
    if (!isEndSwitch) {
      setTargetStep(maxStep);
    }
  }
  void runToDec() {
    if (!isEndSwitch) {
      Serial.println("RUNtoDec");
      setTargetStep(minStep);
    }
  }
  
  void setTargetStep(long value) {
    tmc->setTargetPosition(value);
    stepperTarget = value;
  }
  long getTargetStep() {
    return tmc->getTargetPosition();
  }
  
  long getStepperSpeed() {
    return tmc->getCurrentSpeed();
  }
  int getStepperDir() {
    int d = 0;
    if (tmc->getCurrentSpeed() < 0) d = -1;
    if (tmc->getCurrentSpeed() > 0) d = 1;
    return d;
  }
  void setTargetSpeed(long value) {
    tmc->setTargetSpeed(value);
  }
  
  void setStepperSpeed(long stepsPerSecond) {
    if (stepsPerSecond < TMC4210_MIN_SPEED) {
      stepsPerSecond = TMC4210_MIN_SPEED;
    }
    stepperSpeedSet = stepsPerSecond;
    stepperSpeed = stepsPerSecond;
    if (!motorOff) {
      tmc->setTargetSpeed(stepsPerSecond);
    }
  }
  void setStepperSpeedInPercent(float value) {
    float speedValue = (value * float(TMC4210_MAX_SPEED - TMC4210_MIN_SPEED) / 100.0) + TMC4210_MIN_SPEED;
    if (!isSoftStop) {
      setStepperSpeed(long(speedValue));
      stepperTargetSpeed = long(speedValue);
    }
  }
  long getSettedStepperSpeed() {
    return stepperSpeedSet;
  }
  
  void setStepperAccDec(long value) {
    value = constrain(value, 0, stepperMaxAccDec);
    stepperAcc = value;
    tmc->setAcceleration(value);
  }
  long getStepperAccDec() {
    return stepperAcc;
  }
  
  void updateStepperPos(long value) {
    tmc->setTargetSpeed(0);
    tmc->setCurrentPosition(value);
    tmc->setTargetPosition(value);
    tmc->setTargetSpeed(stepperSpeedSet);
    stepperPos = value;
  }
  
  long getStepperPosDiff() {
    return stepperPosDiff;
  }
  void setStepperPosDiff(long value) {
    stepperPosDiff = value;
  }
  
  void doSingleInc(long value = 0) {
    if (!isEndSwitch) {
      if (value == 0) {
        if (tmc->getCurrentPosition() + incDecSteps > maxStep) {
          setTargetStep(maxStep);
        } else {
          setTargetStep(getTargetStep() + incDecSteps);
        }
      } else {
        if (tmc->getCurrentPosition() + value > maxStep) {
          setTargetStep(maxStep);
        } else {
          setTargetStep(getTargetStep() + value);
        }
      }
    }
  }
  void doSingleDec(long value = 0) {
    if (!isEndSwitch) {
      if (value == 0) {
        if (tmc->getCurrentPosition() - incDecSteps < minStep) {
          setTargetStep(minStep);
        } else {
          setTargetStep(getTargetStep() - incDecSteps);
        }
      } else {
        if (tmc->getCurrentPosition() - value < minStep) {
          setTargetStep(minStep);
        } else {
          setTargetStep(getTargetStep() - value);
        }
      }
    }
  }
  
  void setStepperIncDecSteps(long value) {
    incDecSteps = value;
  }
  long getStepperIncDecSteps() {
    return incDecSteps;
  }
  
  bool targetReached() {
    return tmc->isTargetReached();
  }
};

#endif // STEPPER_H

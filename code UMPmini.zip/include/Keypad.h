#ifndef KEYPAD_H
#define KEYPAD_H

#include <Arduino.h>
#include "esp32-hal-gpio.h"
#include <Adafruit_MCP23X17.h>

class Keypad {
private:
  Adafruit_MCP23X17 *buttonMcp;
  int button;
  unsigned long buttonDownMillis[16];
  bool buttonPress[16];
  bool buttonDown[16];
  bool buttonPressHandled[16];
  bool buttonHold[16];

  // Tasten-Mapping (Index entspricht Taste):
  // 0: 1, 1: 2, 2: 3, 3: INC, 4: 4, 5: 5, 6: 6, 7: DEC, 8: 7, 9: 8, 10: 9, 11: SPD, 12: ',', 13: 0, 14: '+-', 15: RET
  int buttonMap[16] = { 40, 30, 20, 1000, 400, 300, 200, 100, 4000, 3000, 2000, 10, 3, 4, 2, 1 };

  int holdMillis;
  bool numberInputStart;
  long numberDigits;
  bool comma;
  float inputNumber;
  long oldInputNumber;
  long outputNumber;
  bool negative;
  bool inputSizeReached;
  bool inputBegin;
  bool inputEnd;
  int inputEndCode;
  bool incPressed;
  bool decPressed;
  bool setupMode;
  bool motorStop;
  bool intOnly;
  long minValue;
  long maxValue;
  String inputNumberString;
  bool returnOnly;
  bool toZero;
  bool inputAction;
  bool modePressed;

public:
  Keypad() : holdMillis(500),
             numberInputStart(false),
             numberDigits(1),
             comma(false),
             inputNumber(0),
             oldInputNumber(0),
             outputNumber(0),
             negative(false),
             inputSizeReached(false),
             inputBegin(false),
             inputEnd(false),
             inputEndCode(0),
             incPressed(false),
             decPressed(false),
             setupMode(false),
             motorStop(false),
             intOnly(false),
             minValue(-1000000),
             maxValue(1000000),
             inputNumberString(""),
             returnOnly(false),
             toZero(false),
             inputAction(false),
             modePressed(false)
  {
    for (int i = 0; i < 16; i++) {
      buttonDownMillis[i] = 0;
      buttonPress[i] = false;
      buttonDown[i] = false;
      buttonPressHandled[i] = false;
      buttonHold[i] = false;
    }
  }

  void begin(Adafruit_MCP23X17 *mcp) {
    buttonMcp = mcp;
    // Spalten: Setze Pins 7,6,5,4 als Output
    buttonMcp->pinMode(7, OUTPUT);
    buttonMcp->pinMode(6, OUTPUT);
    buttonMcp->pinMode(5, OUTPUT);
    buttonMcp->pinMode(4, OUTPUT);
    // Zeilen: Setze Pins 3,2,1,0 als INPUT_PULLUP
    buttonMcp->pinMode(3, INPUT_PULLUP);
    buttonMcp->pinMode(2, INPUT_PULLUP);
    buttonMcp->pinMode(1, INPUT_PULLUP);
    buttonMcp->pinMode(0, INPUT_PULLUP);
  }

  int keyTrigger() {
    // Falls inputEnd gesetzt ist, Ausgabe (Debug)
    if (inputEnd != 0) {
      Serial.print(inputEnd); 
      Serial.print(" ");
      Serial.println(inputEndCode);
    }
    // Abfrage der Zeilen: Schalte nacheinander alle 4 Spalten ein/aus
    int row[4];
    setCol(0);
    row[0] = getRow();
    setCol(1);
    row[1] = getRow();
    setCol(2);
    row[2] = getRow();
    setCol(3);
    row[3] = getRow();
    int c0 = ((row[1] * 10) + row[0]) + (row[2] * 100) + (row[3] * 1000);
    if (c0 != 0) {
      inputAction = true;
    }
    if (c0 > 0) {
      for (int i = 0; i < 16; i++) {
        if (c0 == buttonMap[i] && !buttonDown[i]) {
          buttonDown[i] = true;
          buttonPress[i] = true;
          buttonDownMillis[i] = millis();
        }
      }
    } else {
      for (int i = 0; i < 16; i++) {
        if (millis() - buttonDownMillis[i] > 100) {
          buttonDown[i] = false;
          buttonPressHandled[i] = false;
          buttonHold[i] = false;
        }
      }
    }
    
    // Verarbeitung der einzelnen Tasten (Beispiele):
    if (buttonPress[0] && !buttonPressHandled[0]) {  // Taste "1"
      inputProcessor(1);
      buttonPress[0] = false;
      buttonPressHandled[0] = true;
      numberInputStart = true;
    }
    if (buttonPress[1] && !buttonPressHandled[1]) {  // Taste "2"
      inputProcessor(2);
      buttonPress[1] = false;
      buttonPressHandled[1] = true;
      numberInputStart = true;
    }
    if (buttonPress[2] && !buttonPressHandled[2]) {  // Taste "3"
      inputProcessor(3);
      buttonPress[2] = false;
      buttonPressHandled[2] = true;
      numberInputStart = true;
    }
    if (buttonPress[4] && !buttonPressHandled[4]) {  // Taste "4"
      inputProcessor(4);
      buttonPress[4] = false;
      buttonPressHandled[4] = true;
      numberInputStart = true;
    }
    if (buttonPress[5] && !buttonPressHandled[5]) {  // Taste "5"
      inputProcessor(5);
      buttonPress[5] = false;
      buttonPressHandled[5] = true;
      numberInputStart = true;
    }
    if (buttonPress[6] && !buttonPressHandled[6]) {  // Taste "6"
      inputProcessor(6);
      buttonPress[6] = false;
      buttonPressHandled[6] = true;
      numberInputStart = true;
    }
    if (buttonPress[8] && !buttonPressHandled[8]) {  // Taste "7"
      inputProcessor(7);
      buttonPress[8] = false;
      buttonPressHandled[8] = true;
      numberInputStart = true;
    }
    if (buttonPress[9] && !buttonPressHandled[9]) {  // Taste "8"
      inputProcessor(8);
      buttonPress[9] = false;
      buttonPressHandled[9] = true;
      numberInputStart = true;
    }
    if (buttonPress[10] && !buttonPressHandled[10]) {  // Taste "9"
      inputProcessor(9);
      buttonPress[10] = false;
      buttonPressHandled[10] = true;
      numberInputStart = true;
    }
    if (buttonPress[13] && !buttonPressHandled[13]) {  // Taste "0"
      inputProcessor(0);
      buttonPress[13] = false;
      buttonPressHandled[13] = true;
      numberInputStart = true;
    }
    // Verarbeitung von Sondertasten (Komma, INC, DEC, SPEED, ENTER, usw.)
    if (buttonPress[12] && !buttonPressHandled[12]) {  // Komma
      buttonPressHandled[12] = true;
    }
    if (buttonPress[12] && !buttonDown[12]) {  // Komma loslassen
      buttonPress[12] = false;
      buttonHold[12] = false;
      inputProcessor(10);
    }
    if (buttonPress[12] && buttonDown[12] && millis() - buttonDownMillis[12] > holdMillis) {  // Komma-Hold (z.B. SETUP)
      buttonHold[12] = true;
      buttonPress[12] = false;
      Serial.println("SETUP");
      inputProcessor(500);
    }
    if (buttonPress[14] && !buttonPressHandled[14]) {  // +/- Taste
      inputProcessor(11);
      buttonPress[14] = false;
      buttonPressHandled[14] = true;
      numberInputStart = true;
    }
    if (buttonPress[3] && !buttonPressHandled[3]) {  // INC Taste
      buttonPressHandled[3] = true;
    }
    if (buttonPress[3] && !buttonDown[3]) {  // INC loslassen
      buttonPress[3] = false;
      buttonHold[3] = false;
      inputProcessor(100);
    }
    if (buttonPress[3] && buttonDown[3] && millis() - buttonDownMillis[3] > holdMillis) {  // INC-Hold
      buttonHold[3] = true;
      buttonPress[3] = false;
      inputProcessor(110);
    }
    if (buttonPress[7] && !buttonPressHandled[7]) {  // DEC Taste
      buttonPressHandled[7] = true;
    }
    if (buttonPress[7] && !buttonDown[7]) {  // DEC loslassen
      buttonPress[7] = false;
      buttonHold[7] = false;
      inputProcessor(200);
    }
    if (buttonPress[7] && buttonDown[7] && millis() - buttonDownMillis[7] > holdMillis) {  // DEC-Hold
      buttonHold[7] = true;
      buttonPress[7] = false;
      inputProcessor(210);
    }
    if (buttonPress[11] && !buttonPressHandled[11]) {  // SPEED / ZERO Taste
      buttonPressHandled[11] = true;
    }
    if (buttonPress[11] && !buttonDown[11]) {  // SPEED / ZERO loslassen
      buttonPress[11] = false;
      buttonHold[11] = false;
      inputProcessor(300);
    }
    if (buttonPress[11] && buttonDown[11] && millis() - buttonDownMillis[11] > holdMillis) {  // SPEED / ZERO-Hold
      buttonHold[11] = true;
      buttonPress[11] = false;
      inputProcessor(310);
    }
    if (buttonPress[15] && !buttonPressHandled[15]) {  // ENTER / CLR Taste
      buttonPressHandled[15] = true;
    }
    if (buttonPress[15] && !buttonDown[15]) {  // ENTER / CLR loslassen
      buttonPress[15] = false;
      buttonHold[15] = false;
      inputProcessor(400);
    }
    if (buttonPress[15] && buttonDown[15] && millis() - buttonDownMillis[15] > holdMillis) {  // ENTER / CLR-Hold
      buttonHold[15] = true;
      buttonPress[15] = false;
      inputProcessor(410);
    }
    return 0;
  }
  
  void setNumberInputStart(bool value) {
    numberInputStart = value;
  }
  
  void setOldInputNumber(long value) {
    oldInputNumber = value;
  }
  
  void inputProcessor(int value) {
    if (value == 100) {  // INC
      if (numberInputStart) {
        numberInputStart = false;
        numberDigits = 1;
        comma = false;
        inputSizeReached = false;
        inputEnd = true;
        inputNumber = inputNumberString.toFloat();
        oldInputNumber = inputNumber;
        inputEndCode = 3;
      }
      incPressed = true;
    }
    if (value == 200) {  // DEC
      if (numberInputStart) {
        numberInputStart = false;
        numberDigits = 1;
        comma = false;
        inputSizeReached = false;
        inputEnd = true;
        inputNumber = inputNumberString.toFloat();
        inputNumberString = "0";
        inputEndCode = 4;
      }
      decPressed = true;
    }
    if (value == 300) {  // SPEED
      if (numberInputStart) {  // Speedeingabe
        numberInputStart = false;
        numberDigits = 1;
        comma = false;
        inputSizeReached = false;
        inputEnd = true;
        inputNumber = inputNumberString.toFloat();
        inputNumberString = "0";
        inputEndCode = 2;
      } else {  // Motorstop
        motorStop = true;
      }
    }
    if (value == 310) { // Nullen
      toZero = true;
    }
    if (value == 400) {  // RETURN
      if (numberInputStart) {  // Eingabe beenden
        numberInputStart = false;
        numberDigits = 1;
        comma = false;
        inputSizeReached = false;
        inputEnd = true;
        inputNumber = inputNumberString.toFloat();
        inputNumberString = "0";
        inputEndCode = 1;
      } else {
        returnOnly = true;
      }
    }
    if (value == 410) {  // CLR
      numberInputStart = false;
      numberDigits = 1;
      comma = false;
      inputSizeReached = false;
      inputEnd = true;
      inputNumberString = "0";
      inputEndCode = -1;
      Serial.println("CLR");
    }
    if (value == 500) {  // SETUP
      setupMode = !setupMode;
    }
    if (value == 10) {  // MODE
      if (numberInputStart) {
        if (inputNumberString.indexOf(".") == -1) {
          inputNumberString += ".";
        }
      } else {
        Serial.println("MODE");
        modePressed = true;
      }
    }
    if (value == 11) {  // +/- umkehren
      inputBegin = true;
      numberInputStart = true;
      if (inputNumberString.indexOf("-") == -1) {
        inputNumberString = "-" + inputNumberString;
      } else {
        inputNumberString = inputNumberString.substring(1);
      }
    }
    if (value >= 0 && value <= 9 && !inputSizeReached) {
      if (!numberInputStart) {
        inputNumber = 0;
        inputNumberString = "0";
        inputBegin = true;
        numberInputStart = true;
      }
      if (inputNumberString == "0" || inputNumberString == "-0") {
        if (inputNumberString == "0") {
          inputNumberString = String(value);
        } else {
          inputNumberString = "-" + String(value);
        }
      } else {
        inputNumberString += String(value);
      }
    }
    if (negative) {
      outputNumber = -inputNumber;
    } else {
      outputNumber = inputNumber;
    }
  }
  
  String getNumberString() {
    return inputNumberString;
  }
  bool getSetup() {
    return setupMode;
  }
  void resetSetup() {
    setupMode = false;
  }
  void setMinMax(long valueMin, long valueMax) {
    minValue = valueMin;
    maxValue = valueMax;
  }
  long getMin() {
    return minValue;
  }
  void setIntOnly(bool value) {
    intOnly = value;
  }
  bool getIntOnly() {
    return intOnly;
  }
  bool getSetupMode() {
    return setupMode;
  }
  bool getIncPressed() {
    return incPressed;
  }
  bool getModePressed() {
    return modePressed;
  }
  bool getIncHold() {
    return buttonHold[3];
  }
  bool getDecPressed() {
    return decPressed;
  }
  bool getDecHold() {
    return buttonHold[7];
  }
  void resetIncDecPressed() {
    incPressed = false;
    decPressed = false;
  }
  void resetModePressed() {
    modePressed = false;
  }
  bool getMotorStop() {
    return motorStop;
  }
  void resetMotorStop() {
    motorStop = false;
  }
  bool getSetToZero() {
    return toZero;
  }
  void resetSetToZero() {
    toZero = false;
  }
  float getInputNumber() {
    return inputNumber;
  }
  long getOutputNumber() {
    return outputNumber;
  }
  bool getInputBegin() {
    return inputBegin;
  }
  void resetInputBegin() {
    inputBegin = false;
  }
  bool getReturnOnly() {
    return returnOnly;
  }
  void resetReturnOnly() {
    returnOnly = false;
  }
  int getInputEnd() {
    if (inputEnd) {
      return inputEndCode;
    } else {
      return 0;
    }
  }
  void resetInputEnd() {
    inputEnd = false;
    negative = false;
    inputEndCode = 0;
  }
  bool getNumberInputStart() {
    return numberInputStart;
  }
  bool getInputAction() {
    return inputAction;
  }
  void resetInputAction() {
    inputAction = false;
  }
  
  void setCol(int col) {
    if (col == 0) {
      buttonMcp->pinMode(7, OUTPUT);
      buttonMcp->digitalWrite(7, LOW);
    } else {
      buttonMcp->pinMode(7, INPUT_PULLUP);
    }
    if (col == 1) {
      buttonMcp->pinMode(6, OUTPUT);
      buttonMcp->digitalWrite(6, LOW);
    } else {
      buttonMcp->pinMode(6, INPUT_PULLUP);
    }
    if (col == 2) {
      buttonMcp->pinMode(5, OUTPUT);
      buttonMcp->digitalWrite(5, LOW);
    } else {
      buttonMcp->pinMode(5, INPUT_PULLUP);
    }
    if (col == 3) {
      buttonMcp->pinMode(4, OUTPUT);
      buttonMcp->digitalWrite(4, LOW);
    } else {
      buttonMcp->pinMode(4, INPUT_PULLUP);
    }
  }
  
  int getRow() {
    int ret = 0;
    if (buttonMcp->digitalRead(3) == LOW) { ret = 1; }
    if (buttonMcp->digitalRead(2) == LOW) { ret = 2; }
    if (buttonMcp->digitalRead(1) == LOW) { ret = 3; }
    if (buttonMcp->digitalRead(0) == LOW) { ret = 4; }
    return ret;
  }
};

#endif // KEYPAD_H
